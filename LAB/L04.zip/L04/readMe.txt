Nella cartella "PDEs" sono presenti gli "sketch" sugli argomenti trattati a lezione.
Nella cartella "VIDEOs" troverete otto clip con animazioni che potete provare a replicare.

Non vi preoccupate se per ora i risultati saranno di poco dissimili ai video che proverete a riprodure.
Tendete, tendete.
Buon lavoro!
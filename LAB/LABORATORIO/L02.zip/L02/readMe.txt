Nella cartella "PDEs" sono presenti gli "sketch" sugli argomenti trattati a lezione.
Nella cartella "IMG" troverete due sotltocartelle.
In "utili" troverete uno scherma esemplificativo delle costanti che mette a disposizione Processing per l'indicazione di angoli in radianti, e una gif che fa vedere come cambia il disegno di una curva di Bezier.
In "esercizi" troverete delle immagini da provare a replicare, usando le funzioni viste a lezione, e un video di animazione del PacMan visto a lezione in cui però, si deve far aprire e chiudere la bocca.

Non vi preoccupate se per ora i risultati saranno di poco dissimili alle figure che proverete a riprodure.
Usate i cicli for e buon lavoro!


 
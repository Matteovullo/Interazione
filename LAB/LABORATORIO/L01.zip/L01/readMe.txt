Nella cartella "PDEs" sono presenti gli "sketch" sugli argomenti trattati a lezione.
Nella cartella "IMG" troverete delle immagini che potete provare a replicare, usando le funzioni viste a lezione.

Non vi preoccupate se per ora i risultati saranno di poco dissimili alle figure che proverete a riprodure.
Usate i cicli for e buon lavoro!


 
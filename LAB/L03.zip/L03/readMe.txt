Nella cartella "PDEs" sono presenti gli "sketch" sugli argomenti trattati a lezione.
Nella cartella "VIDEOs" troverete otto clip con animazioni che potete provare a replicare.

Non vi preoccupate se per ora i risultati saranno di poco dissimili ai video che proverete a riprodure.
Tendete, tendete.
Buon lavoro!


PS. La funzione background() non riconosce il canale alpha. Quindi niente trasparenze nello sfondo, che verrà sempre interpretato con colore totalmente coprente.